# Publish L.I.T.H.A. 2.0 on a new GitHub account

1. Create or sign in to a GitHub account you control.
2. Create a new public repository, e.g. `litha-official`. Do not add a README during creation.
3. Extract the L.I.T.H.A. ZIP on your phone/computer.
4. In the new repository choose **Add file → Upload files**. Upload the CONTENTS of the website folder, including `index.html`, `assets/`, and `.nojekyll`. `index.html` must be at repository root.
5. Commit the upload.
6. Open **Settings → Pages**. Under Build and deployment choose **Deploy from a branch**. Select branch `main` and folder `/ (root)`, then Save.
7. After GitHub finishes deployment, the site will appear at `https://YOUR-USERNAME.github.io/litha-official/`.

## Important
- Do not upload the ZIP itself as the website. Extract it first.
- Keep `assets/` beside `index.html`.
- The current checkout is an order-request flow until a secure server-side payment integration is connected.
- Update social links and contact email in `assets/config.js`.
