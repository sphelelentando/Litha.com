# L.I.T.H.A. Launch Checklist

## Brand
- [ ] Final emblem/logo inserted
- [ ] Final product photography inserted
- [ ] Final fragrance bottle photography inserted
- [ ] Social handles verified
- [ ] Domain purchased/configured

## Catalogue
- [ ] All SKUs confirmed
- [ ] Prices confirmed
- [ ] Stock counts loaded into commerce backend
- [ ] Garment measurements confirmed
- [ ] Product care instructions added

## Commerce
- [ ] Merchant account verified
- [ ] Sandbox payment tests passed
- [ ] Payment callback/ITN validation tested
- [ ] Refund workflow tested
- [ ] Courier workflow tested
- [ ] Order confirmation email tested

## Legal / Operations
- [ ] Company details verified on legal pages
- [ ] POPIA/privacy notice reviewed
- [ ] Consumer/returns terms reviewed
- [ ] Customer support SLA agreed
- [ ] Packaging and fulfilment process dry-run completed

## Web QA
- [ ] iPhone Safari
- [ ] Android Chrome
- [ ] Desktop Chrome
- [ ] Desktop Safari
- [ ] Firefox
- [ ] All navigation links
- [ ] Add-to-cart + quantity + size
- [ ] Wishlist
- [ ] Checkout order receipt
- [ ] 404
- [ ] SEO preview
- [ ] Analytics consent/config if enabled
