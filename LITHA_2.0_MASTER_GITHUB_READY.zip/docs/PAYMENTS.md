# Payments — Production Integration Notes

The static checkout is launch-safe because it does not collect raw card details or expose merchant secrets.

## PayFast production path
Use PayFast's current custom web integration or supported commerce plugin. A production custom integration requires server-side generation/validation, sandbox testing, and secure ITN handling. The server must verify the signature, source, amount and payment data before marking an order paid. Never embed Merchant Key/passphrase in public JavaScript.

Recommended architecture:
1. Customer completes cart and address on the site.
2. Front end POSTs the order to your secure backend/serverless function.
3. Backend creates the canonical order and signs/generates the payment request.
4. Customer completes payment through the provider.
5. Provider notifies your backend.
6. Backend validates the notification and only then marks the order paid.
7. Customer receives confirmation and tracking later.

For a small launch, a hosted commerce platform/plugin can reduce custom payment and security work.

## Static-only fallback
Keep `paymentMode: 'order-request'` in `assets/config.js`. Customers create order requests and payment is arranged separately.
