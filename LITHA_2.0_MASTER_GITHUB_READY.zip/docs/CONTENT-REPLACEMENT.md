# Replacing Placeholder Visuals

The current release deliberately uses geometric brand artwork instead of unapproved stock photography. This prevents visual inconsistency and makes replacement easy.

Recommended final asset structure:
- `assets/images/hero.webp` — 2000px+ wide campaign hero
- `assets/images/lookbook-01.webp` ...
- `assets/images/products/<product-id>-01.webp` ...
- `assets/images/fragrance-noir.webp`
- `assets/images/fragrance-lumiere.webp`
- `assets/logo/emblem.svg`

Optimise photos to WebP/AVIF where possible, include descriptive alt text, and keep original high-resolution masters outside the web repository.


## Official logo installed
The supplied L.I.T.H.A. angular emblem and wordmark from the Solar Reflection artwork are now installed across the header, footer, hero, favicon/app icons, and social sharing card. Source artwork: IMG_7338.png.
