# L.I.T.H.A. Complete Website — Final Static Release

This package is a complete launch-ready **static storefront foundation** for L.I.T.H.A. It can be deployed to GitHub Pages, Netlify, Cloudflare Pages or any static host.

## Included
- Responsive home page and collection storefront
- Men / Women / Active / Accessories / Fragrance filters
- Product quick-view, sizes, wishlist and persistent shopping bag
- Free-delivery progress and local cart persistence
- ASCEND fragrance page
- Brand story, ambassadors, journal and contact pages
- Checkout/order-request flow with unique order reference and downloadable receipt
- FAQ, size guide, shipping/returns, privacy and terms
- SEO metadata, social card, sitemap template, robots.txt
- PWA manifest + service worker
- 404 page and accessibility basics

## Before public commercial launch — required owner actions
1. Replace geometric product placeholders with approved campaign/product photography.
2. Replace the placeholder `L` roundel with the final approved original emblem/logo asset.
3. Verify every price, product name, garment specification, stock count and size measurement against production samples.
4. Open `assets/config.js` and add verified Instagram/TikTok URLs, support email if it changes, and analytics ID if used.
5. Replace `YOUR-DOMAIN.example` in `sitemap.xml`, then add the real domain / CNAME.
6. Have South African counsel review Terms, Privacy and Returns language before live sales.
7. Connect a secure payment backend or commerce platform. Do **not** put PayFast merchant secrets/passphrases in front-end JavaScript.
8. Connect a real newsletter provider and order database if you need server-side customer records.
9. Add courier rates/tracking integration or publish final fixed delivery rules.

## Payment status
The included checkout intentionally does **not** collect card details. It creates a full order request and email/receipt. This is the correct safe state for a purely static GitHub Pages build until a secure server-side payment integration is connected. See `docs/PAYMENTS.md`.

## Test locally
From this folder run:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## GitHub Pages
Upload the contents of this directory to the repository root, enable Pages from the desired branch, and keep `.nojekyll`. Add your custom domain only after DNS is configured.
